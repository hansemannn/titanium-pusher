#import <Foundation/Foundation.h>

//! Project version number for PusherSwift.
FOUNDATION_EXPORT double PusherSwiftVersionNumber;

//! Project version string for PusherSwift.
FOUNDATION_EXPORT const unsigned char PusherSwiftVersionString[];
